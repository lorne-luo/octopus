# Feature: Show Token Response Speed in Logs

## Overview
在日志列表的详情卡片中增加 Token 生成速度（Tokens per Second, tks/s）的显示，帮助用户评估模型响应性能。同时优化了日志详情弹窗的 UI 展示，包括可折叠的重试/错误详情区域。

## Changes

### Backend
- No changes.

### Frontend
- **Log Item**: 修改 `web/src/components/modules/log/Item.tsx`。
  - 新增 `formatSpeed` 工具函数，计算公式：`(inputTokens + outputTokens) / (totalTimeMs / 1000)`。
  - 在日志列表项和详情弹窗的统计信息栏中，新增展示速度指标（使用 Gauge 图标）。
  - 重构详情弹窗结构，使用 `MorphingDialog`。
  - 增加错误信息和重试详情的可折叠区域（Diagnostic Expanded），支持一键复制错误信息。
  - 优化 JSON 内容展示，增加加载状态和延迟渲染逻辑 `DeferredJsonContent` 以提升弹窗打开速度。

### Database
- No changes.
