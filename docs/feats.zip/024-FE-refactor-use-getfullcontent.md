# Refactor: Use GetFullContent for Token Counting

## Overview
重构 Token 统计逻辑，将内容拼接的具体实现下沉到 Model 层。通过在 Request 和 Response 模型上实现 `GetFullContent` 方法，简化 Metrics 层的代码，并提高代码的可维护性和复用性。同时微调了部分前端文案。

## Changes

### Backend
- **Model**: 修改 `internal/transformer/model/model.go`。
  - `InternalLLMRequest` 实现 `GetFullContent()`：拼接所有消息内容。
  - `Message` 实现 `GetFullContent()`：拼接文本、Reasoning Content 和 Tool Call 参数。
  - `InternalLLMResponse` 实现 `GetFullContent()`：拼接所有 Choice 的 Message/Delta 内容。
- **Metrics**: 修改 `internal/relay/metrics.go`。
  - `calcInputTokens` 和 `calcOutputTokens` 方法不再手动拼接字符串，直接调用 `m.InternalRequest.GetFullContent()` 和 `m.InternalResponse.GetFullContent()`。
  - 删除冗余的 `extractMessageContent` 函数。
- **Tokenizer**: 修改 `internal/utils/tokenizer/tokenizer.go`，将 OpenAI Tokenizer 的默认 fallback 编码从 `Cl100kBase` 更新为 `O200kBase` (GPT-4o)，以保持与最新模型的一致性。

### Frontend
- **Localization**: 更新 `zh_hans.json` 和 `zh_hant.json`，将 "Total Time" 的翻译从 "总耗时" 简化为 "耗时"，以节省 UI 空间。

### Database
- No changes.
