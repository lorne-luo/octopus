# Feature: Add API Key Suffix to Channel Attempt Log

## Overview
在渠道尝试（Channel Attempt）日志中记录使用的 API Key 后缀（后4位），并在前端展示。这有助于在多 Key 轮询场景下排查具体是哪个 Key 成功或失败。

## Changes

### Backend
- **Model**: 修改 \`internal/model/log.go\`，\`ChannelAttempt\` 结构体新增 \`ApiKeySuffix\` (string) 字段。
- **Metrics**: 修改 \`internal/relay/metrics.go\`，\`AddAttempt\` 方法签名增加 \`apiKeySuffix\` 参数，并赋值给结构体。
- **Relay Logic**: 修改 \`internal/relay/relay.go\`。
  - 在 \`Handler\` 中处理成功和失败逻辑时，提取当前使用 Key 的后 4 位（如果长度不足则取全部）。
  - 调用 \`metrics.AddAttempt\` 时传入提取的 \`apiKeySuffix\`。

### Frontend
- **API Definition**: 修改 \`web/src/api/endpoints/log.ts\`，\`ChannelAttempt\` 接口增加 \`api_key_suffix\` 字段。
- **Log Item**: 修改 \`web/src/components/modules/log/Item.tsx\`。
  - 在 \`RetryBadgeWithTooltip\` 组件的 Tooltip 内容中，在模型名称后追加显示 \`• sk-...xxxx\`。
  - 同样在详情弹窗的尝试记录列表中展示 Key 后缀。

### Database
- **Schema**: \`channel_attempts\` 存储在 \`relay_logs\` 的 JSON 字段中，无需变更表结构，但 JSON 数据结构发生了变化。
