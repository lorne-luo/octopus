# Feature: Add Channel Type to Logs

## Overview
在日志模型和 Metrics 中增加渠道类型（Channel Type）字段，以便在前端日志列表中展示具体的渠道类型（如 OpenAI, Anthropic, Gemini 等）。

## Changes

### Backend
- **Model**: 修改 \`internal/model/log.go\`，\`RelayLog\` 结构体新增 \`ChannelType\` (int) 字段。
- **Metrics**: 修改 \`internal/relay/metrics.go\`。
  - \`RelayMetrics\` 结构体新增 \`ChannelType\` 字段。
  - 更新 \`SetChannel\` 方法签名，接受 \`channelType\` 参数。
  - 在 \`saveLog\` 中保存 \`ChannelType\`。
- **Relay Logic**: 修改 \`internal/relay/relay.go\`，在调用 \`SetChannel\` 时传入 \`channel.Type\`。

### Frontend
- **API Definition**: 修改 \`web/src/api/endpoints/log.ts\`，\`RelayLog\` 接口增加 \`channel_type\` 字段。
- **Log Card**: 修改 \`web/src/components/modules/log/Item.tsx\`。
  - 在请求内容上方增加一个 Badge，用于显示渠道类型。
  - 引入 \`channel.form\` 翻译命名空间，根据 \`channel_type\` 值展示对应的本地化名称（如 "OpenAI Chat", "Anthropic" 等）。

### Database
- **Schema**: 需要执行 Auto Migration 以在 \`relay_logs\` 表中添加 \`channel_type\` 列（通常由 GORM 自动处理）。
