# Feature: Display Total Token instead of Total Cost in Channel Card

## Overview
将渠道卡片（Channel Card）上展示的统计指标从 "Total Cost"（总成本）变更为 "Total Tokens"（总 Token 数），以更直观地反映渠道的使用量。

## Changes

### Backend
- No changes.

### Frontend
- **Localization**: 更新 `en.json`, `zh_hans.json`, `zh_hant.json`，增加 `channel.card.totalToken` 翻译。
- **Channel Card**: 修改 `web/src/components/modules/channel/Card.tsx`。
  - 图标从 `DollarSign` 更改为 `Cpu`。
  - 显示标签从 `t('totalCost')` 更改为 `t('totalToken')`。
  - 显示数值从 `stats.total_cost` 更改为 `stats.total_token`。

### Database
- No changes.
