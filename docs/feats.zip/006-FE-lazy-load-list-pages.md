# Feature: Lazy Loading for Channel and Group Lists

## Overview
为了提升长列表页面的加载性能和用户体验，将渠道（Channel）和分组（Group）列表页面的分页模式改为无限滚动/懒加载（Lazy Loading）模式。初始加载一定数量的项目，随着用户滚动到底部自动加载更多。

## Changes

### Backend
- No changes.

### Frontend
- **Channel List**: 修改 `web/src/components/modules/channel/index.tsx`。
  - 引入 `IntersectionObserver` 实现滚动监听。
  - 状态管理增加 `visibleCount`，初始显示 16 个，每次加载增加 16 个。
  - 移除原有的分页组件引用（PaginationStore）。
  - 添加底部哨兵元素 `<div id="channel-sentinel" />` 用于触发加载。
- **Group List**: 修改 `web/src/components/modules/group/index.tsx`。
  - 同样引入 `IntersectionObserver`。
  - 初始显示 9 个，每次加载增加 9 个。
  - 移除分页逻辑，添加底部哨兵元素。
- **Toolbar**: 修改 `web/src/components/modules/toolbar/index.tsx`。
  - 定义 `LAZY_LOAD_PAGES` 包含 'channel' and 'group'。
  - 当处于懒加载页面时，隐藏顶部的数字分页控制器（上一页/下一页/页码）。
- **Build Script**: `scripts/build.sh` 权限变更为可执行 (755)。

### Database
- No changes.
