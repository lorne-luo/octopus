# Feature: Docker Compose and Build Scripts

## Overview
为了简化部署和开发流程，增加了 Docker Compose 配置文件以及构建、运行和升级脚本。

## Changes

### Backend / DevOps
- **Docker Compose**: 新增 `docker-compose-lorne.yml`，定义了 octopus 服务，配置了端口映射 (8030:8080)、卷挂载和环境变量。
- **Run Script**: 新增 `run.sh`，用于本地快速编译前端并启动后端服务。
- **Upgrade Script**: 新增 `upgrade.sh`，用于自动化构建 Linux arm64 版本的 Docker 镜像并更新运行中的容器。

### Frontend
- No changes.

### Database
- No changes.
