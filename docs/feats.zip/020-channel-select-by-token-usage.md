# Feature: Track and Select Channel Key by Lowest Token Usage

## Overview
优化渠道下多个 API Key 的选择策略。新增记录每个 Key 的总 Token 消耗量，并在获取 Key 时优先选择 Token 消耗最少的 Key，以实现更精细的负载均衡（Token 均衡）。

## Changes

### Backend
- **Model**: 修改 \`internal/model/channel.go\`。
  - \`ChannelKey\` 结构体新增 \`TotalToken\` (int64) 字段，GORM 默认值为 0。
  - 修改 \`GetChannelKey\` 方法：
    - 遍历所有启用的 Key。
    - 比较逻辑从 `TotalCost` 变更为 `TotalToken`。
    - 记录并返回 `TotalToken` 最小的 Key。
    - 如果所有 Key 都未被选中（例如都不可用），尝试随机返回一个 Candidate（兜底策略）。
- **Relay Logic**: 修改 \`internal/relay/relay.go\`。
  - 在请求成功后的统计逻辑中，累加 \`metrics.Stats.InputToken\` 和 \`OutputToken\` 到 \`rc.usedKey.TotalToken\`。
  - 调用 \`op.ChannelKeyUpdate\` 更新数据库。

### Frontend
- No changes.

### Database
- **Schema**: 需要执行 Auto Migration 以在 \`channel_keys\` 表（或存储 Key 的相关表/JSON结构）中添加 \`total_token\` 列。
