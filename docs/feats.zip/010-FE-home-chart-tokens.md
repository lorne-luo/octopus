# Feature: Add Tokens Used to Home Chart

## Overview
在首页的统计图表中增加 "Tokens Used"（Token 消耗量）指标，替换原有的 "Total Cost"（总消费）曲线显示，或作为新增维度（根据 diff 看来是将图表的主数据从 Cost 改为了 Token，但保留了 Cost 的数字展示，或者是在图表中替换了显示重点，具体看代码是替换了 AreaChart 的 dataKey）。

## Changes

### Backend
- No changes.

### Frontend
- **Localization**: 更新 `en.json`, `zh_hans.json`, `zh_hant.json`，增加 `chart.totalTokens` 翻译键值。
- **Chart Component**: 修改 `web/src/components/modules/home/chart.tsx`。
  - 数据处理逻辑中，将图表数据源的 `total_cost` 字段替换/映射为 `total_token`。
  - 统计汇总 (`totals`) 中增加 `tokens` 字段的累加计算。
  - 统计卡片区域增加 "Tokens Used" 的数字展示区块。
  - 图表 (`AreaChart`) 的 `dataKey` 从 `total_cost` 改为 `total_token`，并应用新的渐变色填充 `fillTotalToken`。

### Database
- No changes.
