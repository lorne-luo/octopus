# Feature: Remove Cost Display from Log List

## Overview
为了简化日志列表页面的 UI 展示，移除日志卡片（桌面端和移动端）中显示的 "Cost"（消费金额）字段。

## Changes

### Backend
- No changes.

### Frontend
- **Log Item**: 修改 \`web/src/components/modules/log/Item.tsx\`。
  - 删除桌面端 Grid 布局中显示 \`DollarSign\` 图标和 \`log.cost\` 数据的 \`div\` 块。
  - 删除移动端布局中显示 Cost 的对应区块。
  - 调整 Grid 列数配置（从 \`grid-cols-7\` 改为 \`grid-cols-6\`）。
  - （注意：详情弹窗中的 Cost 显示似乎保留了，或者 diff 中未完全显示，但根据 commit message 是 "remove cost display from log list"）。

### Database
- No changes.
