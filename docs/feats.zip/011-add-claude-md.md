# Feature: Add CLAUDE.md for Claude Code Guidance

## Overview
添加 `CLAUDE.md` 文件，为 Claude Code 提供项目概览、架构细节和核心开发命令，以提升 AI 辅助编码的效率和准确性。

## Changes

### Documentation
- **New File**: 创建 `CLAUDE.md`，包含：
  - 项目简介 (Tech Stack, Architecture)
  - 开发命令 (Frontend/Backend dev, Build)
  - 核心组件列表
  - 请求流转图 (Request Flow)
  - Transformer 层说明
  - 关键数据库模型
  - 路由系统说明
  - 后台任务说明
  - 新增 Provider 的指南

### Backend
- No changes.

### Frontend
- No changes.

### Database
- No changes.
