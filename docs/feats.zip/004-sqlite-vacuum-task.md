# Feature: SQLite Vacuum Task

## Overview
针对 SQLite 数据库增加定时 Vacuum 任务，以定期整理数据库文件，释放未使用的空间并优化性能。

## Changes

### Backend
- **Database Operation**: 在 `internal/db/db.go` 中增加 `Vacuum` 函数，仅当数据库类型为 SQLite 时执行 `VACUUM` 命令。
- **Task Scheduling**: 在 `internal/task/init.go` 中注册 `sqlite_vacuum` 任务，配置为每 24 小时执行一次。

### Frontend
- No changes.

### Database
- No changes (Schema unchanged, maintenance operation added).
