# Feature: Channel List Sorting Improvement

## Overview
优化渠道列表的排序逻辑。原逻辑仅按 ID 排序，新逻辑优先按请求总数（成功+失败）降序排列，请求数相同时再按 ID 升序排列，以确保列表顺序的稳定性。

## Changes

### Backend
- No changes.

### Frontend
- **Channel Component**: 修改 `web/src/components/modules/channel/index.tsx` 中的 `filteredChannels` useMemo 逻辑。
  - 新增排序规则：`(countA === countB) ? (idA - idB) : (countB - countA)`。

### Database
- No changes.
