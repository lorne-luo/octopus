# Feature: Clear Metadata for Unsupported Providers

## Overview
部分 LLM 提供商（如 Cerebras, Groq）不支持请求中的 metadata 字段。为了兼容这些服务商，需要针对性地在请求发出前清除 metadata 信息。

## Changes

### Backend
- **Configuration**: 在 `internal/conf/const.go` 中定义了不支持 metadata 的提供商列表 `NoMetadataProvider` (目前包含 "cerebras.ai", "groq.com")。
- **Transformer**: 在 `internal/transformer/outbound/openai/chat.go` 的 `TransformRequest` 方法中增加逻辑：检查请求的 baseURL 是否包含在 `NoMetadataProvider`列表中。如果匹配，则将 request.Metadata 置为 nil。

### Frontend
- No changes.

### Database
- No changes.
