# Feature: Display Total Retries in Log Card

## Overview
在日志卡片中显示请求的总重试次数，并在 Anthropic 流式响应处理中优化 Stop Reason 的记录逻辑。同时升级了构建脚本中的依赖。

## Changes

### Backend
- **Transformer**: 修改 `internal/transformer/inbound/anthropic/messages.go`，在流式转换时记录 `stopReason`，以便后续合并 Usage 信息。
- **Build Script**: 修改 `upgrade.sh`，在构建前安装 `baseline-browser-mapping@latest` 依赖。

### Frontend
- **Log Card**: 修改 `web/src/components/modules/log/Item.tsx`。
  - 优化布局，在宽屏模式下将重试次数 Badge 显示在模型名称旁边。
  - 在移动端布局中同步增加重试次数显示。
  - 优化日志详情弹窗中的统计信息展示布局。

### Database
- No changes.
