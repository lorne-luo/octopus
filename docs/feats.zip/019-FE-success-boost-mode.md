# Feature: Add SuccessBoost Group Mode

## Overview
新增 "SuccessBoost"（成功提升）分组负载均衡模式。在此模式下，当某个渠道成功响应请求后，系统会尝试提升该渠道在分组中的优先级（Priority 值减小），使其在故障转移（Failover）逻辑中更容易被选中。

## Changes

### Backend
- **Model**: 修改 \`internal/model/group.go\`，新增常量 \`GroupModeSuccessBoost = 5\`。
- **Balancer**:
  - 新增 \`internal/relay/balancer/success_boost.go\` (实际上逻辑写在 \`balancer.go\` 或新文件，diff 显示是在 \`balancer.go\` 中注册并在同包下实现)。
  - 实现 \`SuccessBoost\` 结构体，其 \`Select\`和 \`Next\` 方法复用 \`Failover\` 的逻辑（按优先级排序）。
  - 注册新的 Balancer 类型。
- **Operation**: 修改 \`internal/op/group.go\`，新增 \`GroupItemPromote\` 函数。
  - 逻辑：找到当前 Item，将其与优先级更高（Priority 值更小）的前一个 Item 交换 Priority 值。如果优先级相同，则强制使当前 Item 的 Priority 减 1。
  - 包含数据库事务处理和缓存刷新。
- **Relay Logic**: 修改 \`internal/relay/relay.go\`。
  - 在请求成功后的 Hook 中，判断如果 Group Mode 是 \`SuccessBoost\`，则启动 Goroutine 调用 \`op.GroupItemPromote\`。

### Frontend
- **Localization**: 更新 \`en.json\`, \`zh_hans.json\`, \`zh_hant.json\`，增加 \`successBoost\` 的翻译。
- **API Definition**: 修改 \`web/src/api/endpoints/group.ts\`，\`GroupMode\` 枚举增加 \`SuccessBoost\`。
- **Group Card/Editor**: 修改 \`web/src/components/modules/group/Card.tsx\` 和 \`Editor.tsx\`，在模式选择按钮列表中加入 \`SuccessBoost\` 选项（映射值为 5）。

### Database
- No changes to schema, but \`GroupItem\` priority values will change dynamically.
