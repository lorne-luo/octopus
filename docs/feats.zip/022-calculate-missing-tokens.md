# Feature: Calculate Tokens When Usage is Missing

## Overview
增强 Relay 层的健壮性。当上游响应中缺失 Usage 信息或 Token 计数为 0 时，系统将自动基于请求和响应的内容，使用 Tokenizer 进行估算补全，确保计费和统计数据的完整性。

## Changes

### Backend
- **Metrics**: 修改 `internal/relay/metrics.go`。
  - 在 `SetInternalResponse` 中，检查 `m.Stats.InputToken` 和 `m.Stats.OutputToken`。如果为 0，则调用 `calcInputTokens` 和 `calcOutputTokens` 进行补全。
  - 新增 `calcInputTokens` 方法：遍历 `InternalRequest` 的所有 Message Content 进行拼接和 Token 计数。
  - 新增 `calcOutputTokens` 方法：遍历 `InternalResponse` 的 Choices (Message 和 Delta) 进行拼接和 Token 计数。
  - 优化费用计算逻辑：如果没有 Usage 详情，回退到基于总 Token 数和单价的简单计算公式。
- **Tests**: 新增 `internal/relay/metrics_test.go`，测试 Usage 缺失和 Usage 存在两种场景下的 Token 统计行为。

### Frontend
- No changes.

### Database
- No changes.
