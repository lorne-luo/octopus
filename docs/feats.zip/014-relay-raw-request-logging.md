# Feature: Add Raw Request/Response Logging

## Overview
增强 Relay 层的日志记录能力，记录原始的请求体（Raw Request）和响应体（Raw Response），以便于调试和问题排查。

## Changes

### Backend
- **Metrics**: 修改 `internal/relay/metrics.go`。
  - `RelayMetrics` 结构体新增 `RawRequest` (string) 和 `RawResponse` (*strings.Builder) 字段。
  - 新增 `SetRawRequest` 和 `AppendRawResponse` 方法。
  - 在 `saveLog` 方法中，将 `RawRequest`（去除换行符后）赋值给 `relayLog.RequestContent`。
  - 如果 `InternalResponse` 为空，将 `RawResponse` 赋值给 `relayLog.ResponseContent`。
- **Relay Handler**: 修改 `internal/relay/relay.go`。
  - `parseRequest` 现在返回原始 `body`。
  - 在 `Handler` 中调用 `metrics.SetRawRequest(body)` 记录原始请求。
  - 在 `handleStreamResponse` 中调用 `metrics.AppendRawResponse(data)` 记录流式响应块。
  - 在 `handleResponse` 中，将非流式 JSON 响应也记录到 `metrics.AppendRawResponse`。

### Frontend
- No changes.

### Database
- No changes.
