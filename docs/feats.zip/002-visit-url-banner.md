# Feature: Display Visit URL in Banner

## Overview
在服务启动时的 Banner 信息中显示访问地址（Visit URL），方便开发和运维人员快速获知服务运行端口并直接访问。

## Changes

### Backend
- **Startup Logic**: 修改 `cmd/start.go`，调整 `conf.PrintBanner()` 的调用顺序，确保配置加载后再打印 Banner，以便获取正确的端口信息。
- **Banner Output**: 修改 `internal/conf/banner.go`，在 Banner 中增加 "Visit URL" 行，格式为 `http://localhost:<port>`，并添加分割线美化输出。

### Frontend
- No changes.

### Database
- No changes.
