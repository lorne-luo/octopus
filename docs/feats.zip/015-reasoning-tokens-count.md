# Fix: Correctly Count Reasoning Tokens in Usage

## Overview
修复 Gemini 和 OpenAI 协议转换中 Reasoning Tokens 的统计问题。确保 Reasoning Tokens 被正确计入 Completion Tokens 和 Total Tokens 中。

## Changes

### Backend
- **Gemini Transformer**: 修改 `internal/transformer/outbound/gemini/messages.go`。
  - 在处理 `UsageMetadata` 时，将 `ThoughtsTokenCount` 加到 `CompletionTokens` 和 `TotalTokens` 中。
- **OpenAI Transformer**: 修改 `internal/transformer/outbound/openai/response.go`。
  - 在处理 `OutputTokenDetails.ReasoningTokens` 时，将其加到 `CompletionTokens` 和 `TotalTokens` 中。

### Frontend
- No changes.

### Database
- No changes.
