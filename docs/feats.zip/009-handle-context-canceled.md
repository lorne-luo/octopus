# Feature: Handle Context Canceled Error

## Overview
优化 Relay 层的错误处理逻辑。当客户端主动断开连接（Context Canceled）时，不再记录为通用的转换错误，而是明确返回 "request canceled by client" 错误，避免日志中出现误导性的报错信息。

## Changes

### Backend
- **Relay Logic**: 修改 `internal/relay/relay.go` 中的 `handleResponse` 方法。
  - 在调用 `TransformResponse`（出站和入站）出错后，增加对 `ctx.Err() == context.Canceled` 的判断。
  - 如果是因为上下文取消导致的错误，返回明确的 `fmt.Errorf("request canceled by client: %w", context.Canceled)`。

### Frontend
- No changes.

### Database
- No changes.
