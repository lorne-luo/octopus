# Feature: Update Tokenizer Integration

## Overview
升级和增强 Tokenizer 模块，集成 Anthropic 官方 Tokenizer，优化 Token 计数逻辑，并添加了更完善的测试用例。

## Changes

### Backend
- **Dependencies**:
  - 新增 `github.com/qhenkart/anthropic-tokenizer-go` 用于精确计算 Anthropic 模型的 Token。
  - 新增 `github.com/stretchr/testify` 用于单元测试。
  - 升级 `github.com/tiktoken-go/tokenizer`。
- **Tokenizer Logic**: 修改 `internal/utils/tokenizer/tokenizer.go`。
  - `CountTokens` 函数逻辑增强：
    - 根据模型名称判断是否为 Anthropic 模型。如果是，尝试使用 Anthropic Tokenizer。
    - 如果不是或 Anthropic Tokenizer 初始化失败，回退到 OpenAI Tiktoken。
    - Tiktoken 的回退编码从 `Cl100kBase` 升级为 `O200kBase` (GPT-4o)。
  - 引入 `sync.Once` 懒加载 Anthropic Tokenizer。
- **Tests**: 新增 `internal/utils/tokenizer/tokenizer_test.go`，覆盖多种场景（空内容、OpenAI 模型、Anthropic 模型、中文内容等）的测试用例。

### Frontend
- No changes.

### Database
- No changes.
