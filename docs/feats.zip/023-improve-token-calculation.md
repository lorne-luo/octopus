# Feature: Improve Token Calculation and Cost Accuracy

## Overview
进一步提升 Token 计算的精度和系统的稳定性。将 Token 计数相关字段的数据类型升级为 `int64` 以支持更大数值，优化费用计算逻辑以准确处理 Anthropic 的缓存 Token 计费，并增强无响应情况下的 Token 统计兜底机制。

## Changes

### Backend
- **Model**: 修改 `internal/model/log.go`，将 `InputTokens`和 `OutputTokens` 字段类型从 `int` 修改为 `int64`。
- **Metrics**: 修改 `internal/relay/metrics.go`。
  - 更新费用计算公式：
    - 针对 Anthropic Usage，准确区分 `CachedTokens` (CacheRead), `PromptTokens` (Input), 和 `CacheCreationInputTokens` (CacheWrite) 的计费。
    - 针对普通 Usage，从 Input Token 中扣除 Cached Token 后再计算 Input 费用。
  - 新增 `extractMessageContent` 辅助函数，全面提取消息内容（包括 Tool Calls 和 Reasoning Content）。
  - 新增 `CalcTokensFromRequest` 方法：仅计算 Input Token 和 Input Cost，用于无响应时的兜底统计。
  - `saveLog` 方法适配 `int64` 类型，并优化 `RawRequest` 的换行符处理 (`strings.ReplaceAll`)。
- **Relay Logic**: 修改 `internal/relay/relay.go`。
  - 在请求处理流程中，即使发生错误或流式响应中断，也确保调用 `collectResponse` 或 `metrics.CalcTokensFromRequest` 来记录已消耗的 Input Token。

### Frontend
- No changes.

### Database
- No changes (GORM handles int/int64 mapping seamlessly).
