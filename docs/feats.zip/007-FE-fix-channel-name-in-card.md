# Feature: Fix Channel Name Display in Card Content

## Overview
修复渠道详情卡片在查看模式下的标题显示问题。原逻辑在非编辑模式下显示通用的 "View" 标题，现改为直接显示渠道名称，提升信息的直观性。

## Changes

### Backend
- No changes.

### Frontend
- **Channel Card**: 修改 `web/src/components/modules/channel/CardContent.tsx`。
  - 将 `<h2 className="text-2xl font-bold text-card-foreground">` 的内容逻辑从 `{isEditing ? t('title.edit') : t('title.view')}` 修改为 `{isEditing ? t('title.edit') : channel.name}`。

### Database
- No changes.
